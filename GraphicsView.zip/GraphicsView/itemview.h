#ifndef ITEMVIEW_H
#define ITEMVIEW_H
#include "Types.h"

#include <QGraphicsView>
#include <QGraphicsItem>
#include <QGraphicsScene>

// ItemView is the canvas
class ItemView : public QGraphicsView
{
public:
    ItemView();

    QGraphicsPolygonItem* add_Polygon();
    QGraphicsEllipseItem* add_Circle();
    QGraphicsRectItem* add_Rectangle();
    QGraphicsLineItem* add_Line();
    QGraphicsLineItem* add_Path();
    void rectDrawingDirection();
    void pathDrawingDirection();
    void createBackground();
    QPoint* mapToBackground(QPoint point);

    // Mouse events for all shapes
    void mousePressEvent(QMouseEvent*) override;
    void mouseReleaseEvent(QMouseEvent*) override;
    void mouseMoveEvent(QMouseEvent*) override;
    void mouseDoubleClickEvent(QMouseEvent*) override;

    // Mouse events for drawing a rectangle
    void rectangleMousePressEvent(QMouseEvent*);
    void rectangleMouseReleaseEvent(QMouseEvent*);
    void rectangleMouseMoveEvent(QMouseEvent*);

    // Mouse events for drawing a line
    void lineMousePressEvent(QMouseEvent*);
    void lineMouseReleaseEvent(QMouseEvent*);
    void lineMouseMoveEvent(QMouseEvent*);

    // Mouse events for drawing an ellipse
    void circleMousePressEvent(QMouseEvent*);
    void circleMouseReleaseEvent(QMouseEvent*);
    void circleMouseMoveEvent(QMouseEvent*);

    // Mouse events for drawing a polygon
    void polygonMousePressEvent(QMouseEvent*);
    void polygonMouseReleaseEvent(QMouseEvent*);
    void polygonMouseMoveEvent(QMouseEvent*);
    void polygonMouseDoubleClickEvent();

    // Mouse events for drawing a path
    void pathMousePressEvent(QMouseEvent*);
    void pathMouseReleaseEvent(QMouseEvent*);
    void pathMouseMoveEvent(QMouseEvent*);
    void pathMouseDoubleClickEvent(QMouseEvent*);

public slots:
    void recieveLayerType(Layer::LayerType);
    void recieveShapeType(Shapes::ShapeType);

private:
    int x;
    int m_clicks = 0;
    int m_pressCount = 0;
    int m_releaseCount = 0;
    QPointF m_point1;
    QPointF m_point2;
    QPointF m_tempPoint;
    QGraphicsScene* scene;
    QGraphicsItem* m_currentItem;
    QGraphicsEllipseItem* circle;
    QGraphicsRectItem* rectangle;
    QGraphicsLineItem* line;
    QGraphicsLineItem* midLine;
    QGraphicsLineItem* topLine;
    QGraphicsLineItem* bottomLine;
    QGraphicsLineItem* startLine;
    QGraphicsLineItem* endLine;
    QVector<QGraphicsLineItem*> path;
    QPointF m_pressedPos; // Position where mouse was pressed
    QPointF m_releasedPos; // Position where mouse was released
    bool m_mouseIsPressed = false;
    bool m_firstClick;
    bool m_readyToDraw;
    QVector<QPointF> m_points;
    Layer::LayerType m_layerType = Layer::LayerType::M1;
    Shapes::ShapeType m_shapeType = Shapes::ShapeType::Rectangle;
};

#endif // ITEMVIEW_H
