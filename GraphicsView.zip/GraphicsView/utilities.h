#ifndef UTILITIES_H
#define UTILITIES_H

#include "Types.h"
#include <iostream>
#define debug 0

void printShapeType(Shapes:: ShapeType shape_type) {
    if (!debug) {
        return;
    }
    switch (shape_type) {
        case Shapes::ShapeType::Rectangle:
            std::cout << "ShapeType = Rectangle" << std::endl;
            break;
        case Shapes::ShapeType::Line:
            std::cout << "ShapeType = Line" << std::endl;
            break;
        case Shapes::ShapeType::Circle:
            std::cout << "ShapeType = Circle" << std::endl;
            break;
        case Shapes::ShapeType::Polygon:
            std::cout << "ShapeType = Polygon" << std::endl;
            break;
        case Shapes::ShapeType::Path :
            std::cout << "ShapeType = Path" << std::endl;
            break;
    }
}

void print(const std::string& str) {
    std::cout << str << std::endl;
}
#endif // UTILITIES_H
